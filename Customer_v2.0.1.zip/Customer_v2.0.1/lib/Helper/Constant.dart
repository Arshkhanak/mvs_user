const String appName = 'eShop Multivendor';

const String packageName = 'wrteam.eshop.multivendor';
const String androidLink =
    'https://play.google.multivendor/store/apps/details?id=';

const String iosPackage = 'wrteam.eshop.multivendor';
const String iosLink = 'your ios link here';
const String appStoreId = '123456789';

const String deepLinkUrlPrefix = 'https://eshopmultivendor.page.link';
const String deepLinkName = 'eshop';

const int timeOut = 50;
const int perPage = 10;

const String baseUrl = 'PLACE_YOUR_BASE_URL_HERE';

const String jwtKey = "PLACE_YOUR_SECRET_KEY_HERE";

